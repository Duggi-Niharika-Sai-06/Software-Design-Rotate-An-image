#include "pgm.h"
#include <fstream>
#include <cmath>
#include <string>
#include<vector>
using namespace std;



bool pgm::ReadPPMFile(std::ifstream& fin) {
    if (fin.fail()) {
        return false;
    };
    fin >> magicNumber;
    
    fin >> width >> height;
    fin >> intensity;
    for (int i = 0; i < height; i++) {
        std::vector<pgm> pixel_vector;
        for (int j = 0; j < width; j++) {
            pgm temp;
            fin >> temp;
            pixel_vector.push_back(temp);
        }
        picture_data.push_back(pixel_vector);
    }
    return true;
}

bool pgm::WritePPMFile(std::ofstream& fout) {
    if (fout.fail()) {
        return false;
    }
    fout << magicNumber << "\n";
    fout << width << " " << height << "\n";
    if (width == 0 || height == 0) {
        return false;
    }
    fout << intensity << "\n";
    for (int i = 0; i < height; i++) {
        for (int j = 0; j < width; j++) {
            fout << picture_data[i][j]  << "\n";
        }
    }
    return true;
}

void pgm::FlipX() {
    for (int i = 0; i < height/2; i++) {
        std::vector<pgm> temp = picture_data[i];
        picture_data[i] = picture_data[picture_data.size()-i-1];
        picture_data[picture_data.size()-i-1] = temp;
    }
}

//flip rotate will do 90

void pgm::FlipRotate()
{
 
    // Traverse each cycle
    for (int i = 0; i < height ; i++) {
   
        for (int j = i; j < height ; j++) {
   std::vector<pgm> temp = picture_data[i];
            // Swap elements of each cycle
            // in clockwise direction
            
           swap(picture_data[i][j],picture_data[j][i]);
           
             temp[i]= picture_data[j][i];
        }
    }
}



/**
void pgm::FlipRotate() {

double radians = (90 * M_PI) / 180;
    int sinf = (int) sin(radians);
    int cosf = (int) cos(radians);

double x0 = 0.5 * (width - 1);     // point to rotate about
    double y0 = 0.5 * (height - 1);     // center of image


    for (int x = 0; x < width; x++) {
    std::vector<pgm> temp = picture_data[x];
        for (int y = 0; y < height; y++) {
        
            long double a = x - x0;
            long double b = y - y0;
            int xx = (int) (+a * cosf - b * sinf + x0);
            int yy = (int) (+a * sinf + b * cosf + y0);

            if (xx >= 0 && xx < width && yy >= 0 && yy < height) {
                picture_data[(y * height + x) * 3 + 0] = picture_data[(yy *height + xx) * 3 + 0];
                picture_data[(y * height + x) * 3 + 1] = picture_data[(yy *height + xx) * 3 + 1];
                picture_data[(y * height + x) * 3 + 2] = picture_data[(yy *height + xx) * 3 + 2];
            }
        }
        picture_data[x] = temp;
    }
    
    
}


**/


/**


void pgm::FlipRotate() {
    for (int i = 0; i < width/2; i++) {
        std::vector<pgm> temp = picture_data[i];
        picture_data[i] = picture_data[(picture_data.size())-i-1];
        picture_data[picture_data.size()-i-1] = temp;
    }
}










void pgm::FlipY() {
    for (unsigned int i = 0; i < picture_data.size(); i++) {
        std::vector<pgm> temp = picture_data[i];
        for (unsigned int j = 0; j < temp.size(); j++) {
            temp[j] = picture_data[i][width-j-1];
        }
        picture_data[i] = temp;
    }
}


**/





void pgm::InvertPixelIntensity() {
    for (unsigned int i = 0; i < picture_data.size(); i++) {
        std::vector<pgm> temp = picture_data[i];
        for (unsigned int j = 0; j < temp.size(); j++) {
            temp[j].red = abs(temp[j].red - intensity);
            temp[j].green = abs(temp[j].green - intensity);
            temp[j].blue = abs(temp[j].blue - intensity);
        }
        picture_data[i] = temp;
    }
}



void pgm::FlipZ() {
    for (int i = 0; i < height/2; i++) {
        std::vector<pgm> temp = picture_data[i];
        picture_data[i] = picture_data[picture_data.size()-i-1];
        picture_data[picture_data.size()-i-1] = temp;
    }
}


void pgm::Flip90R() {
    for (int i = 0; i < height/2; i++) {
        std::vector<pgm> temp = picture_data[i];
        picture_data[i] = picture_data[picture_data.size()-i-1];
        picture_data[picture_data.size()-i-1] = temp;
    }
}



void pgm::Flip90L() {
    for (int i = 0; i < height/2; i++) {
        std::vector<pgm> temp = picture_data[i];
        picture_data[i] = picture_data[picture_data.size()-i-1];
        picture_data[picture_data.size()-i-1] = temp;
    }
}


void pgm::Flip180R() {
    for (int i = 0; i < height/2; i++) {
        std::vector<pgm> temp = picture_data[i];
        picture_data[i] = picture_data[picture_data.size()-i-1];
        picture_data[picture_data.size()-i-1] = temp;
    }
}
void pgm::Flip180L() {
    for (int i = 0; i < height/2; i++) {
        std::vector<pgm> temp = picture_data[i];
        picture_data[i] = picture_data[picture_data.size()-i-1];
        picture_data[picture_data.size()-i-1] = temp;
    }
}
void pgm::Flip270R() {
    for (int i = 0; i < height/2; i++) {
        std::vector<pgm> temp = picture_data[i];
        picture_data[i] = picture_data[picture_data.size()-i-1];
        picture_data[picture_data.size()-i-1] = temp;
    }
}
void pgm::Flip270L() {
    for (int i = 0; i < height/2; i++) {
        std::vector<pgm> temp = picture_data[i];
        picture_data[i] = picture_data[picture_data.size()-i-1];
        picture_data[picture_data.size()-i-1] = temp;
    }
}

















