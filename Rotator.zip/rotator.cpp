#include <iostream>
#include <cmath>

#include "pgm.cpp"
#include "pgm.h"

using namespace std;
class Rotator{

  static Rotator *instance;
  int data;

Rotator()
{
  data=0;
}

public:
  static Rotator *getInstance()
  {
    if(!instance)
    instance=new Rotator;
    return instance;
  }

};

Rotator *Rotator::instance=0;

int main(int argc, char** argv) {

  Rotator *s;
    if (argc < 4) {
        std::cout << "Usage: inputfile outputfile [XYIZ and 90 sth like that]\n";
        return -1;
    }


    std::ifstream fin;
    fin.open(argv[1]);

    pgm picture;

    bool able_to_read_ppm_file = picture.ReadPPMFile(fin);
    if(!able_to_read_ppm_file) {
        std::cout << "Error: unable to read PPM file " << argv[1] << "\n";
        return -1;
    }

    if (argc == 5) {
      int angle=atoi(argv[4]);
        if (*argv[3] == 'r' && angle==180) {
            picture.FlipX();
        } else if (*argv[3] == 'r' && angle==90) {
            picture.FlipRotate();
        } else if (*argv[3] == 'r' && angle== 270) {
            picture.InvertPixelIntensity();
        } /*else if (*argv[3] == 'Z' && *argv[4]== 'r') {
            picture.FlipZ();
        }
        else if (*argv[3] == 'Z' && *argv[4]== 'r') {
            picture.Flip90R();
        }
        else if (*argv[3] == 'Z' && *argv[4]== 'r') {
            picture.Flip90L();
        }
        else if (*argv[3] == 'Z' && *argv[4]== 'r') {
            picture.Flip180R();
        }
        else if (*argv[3] == 'Z' && *argv[4]== 'r') {
            picture.Flip180L();
        }
        else if (*argv[3] == 'Z' && *argv[4]== 'r') {
            picture.Flip270R();
        }
        else if (*argv[3] == 'Z' && *argv[4]== 'r') {
            picture.Flip270L();
        }*/

        else {
            std::cout << "Error: " << argv[3] << " is an invalid command. Use either X, Y, or I.\n";
            return -1;
        }
    }

    std::ofstream fout;
    fout.open(argv[2]);
    bool able_to_write_ppm_file = picture.WritePPMFile(fout);
    if (!able_to_write_ppm_file) {
        std::cout << "Error: unable to write uninitialized PPM file " << argv[2] << "\n";
        return -1;
    }
    fout.close();
}
