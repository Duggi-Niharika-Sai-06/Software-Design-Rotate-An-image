#ifndef PGM_H
#define PGM_H
#include <fstream>
#include <string>
#include<vector>
using namespace std;
class pgm{
 private:
        std::vector<std::vector<pgm> > picture_data;
        std::string magicNumber;
        int width;
        int height;
        int intensity;
    public:
        bool ReadPPMFile(std::ifstream& fin);
        bool WritePPMFile(std::ofstream& fout);
        void FlipY();

        void FlipRotate();
        void FlipX();
        void FlipZ();
        void Flip90R();
        void Flip90L();
        void Flip180R();
        void Flip180L();
        void Flip270R();
        void Flip270L();


        void InvertPixelIntensity();
public:
        int red;
        int green;
        int blue;
        string ptwo;
   	string pthree;
        //pgm(0, 0, 0) {};
        //pgm(int _r, int _g, int _b): red(_r), green(_g), blue(_b) {};
};

std::ifstream& operator >> (std::ifstream& fin, pgm& temp) {
    fin >> temp.red;
    fin >> temp.green;
    fin >> temp.blue;
    return fin;
}

std::ofstream& operator << (std::ofstream& fout, pgm& temp) {
    fout << temp.red << " ";
    fout << temp.green << " ";
    fout << temp.blue;
    return fout;

};

#endif
